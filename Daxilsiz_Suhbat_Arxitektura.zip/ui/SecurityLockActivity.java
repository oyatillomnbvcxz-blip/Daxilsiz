package com.daxilsiz.suhbat.ui;

/**
 * Sandiqqa kirish uchun PIN-kod va Biometrik (Barmoq izi) qobig'i.
 */
public class SecurityLockActivity {

    public boolean verifyAccess(String inputPin, String correctHash) {
        // PIN-kodni solishtirish va xavfsiz sandiqni ochish
        return inputPin.hashCode() == correctHash.hashCode();
    }

    // Agar ketma-ket noto'g'ri kod kiritilsa, sandiqni vaqtincha bloklash
    public void handleBruteForceProtection(int attemptCount) {
        if (attemptCount >= 5) {
            // Tizimni 30 daqiqaga bloklash yoki ma'lumotlarni o'chirish mexanizmi
        }
    }
}
