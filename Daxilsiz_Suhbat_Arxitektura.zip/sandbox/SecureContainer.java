package com.daxilsiz.suhbat.sandbox;

import android.view.WindowManager;
import android.app.Activity;

/**
 * Ilovani tashqi muhit, viruslar va xakerlardan ajratib turuvchi 
 * xavfsiz "Sandiq" (Sandbox) boshqaruvi.
 */
public class SecureContainer {

    // Ekranni rasmga olish (screenshot) va video yozishdan to'liq bloklash
    public static void preventScreenshots(Activity activity) {
        activity.getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        );
    }

    // Ilovadan chiqilganda xotirani (RAM) va vaqtinchalik izlarni butunlay tozalash
    public void wipeMemory() {
        System.gc();
        // Vaqtinchalik operativ xotiradagi massivlarni nolga tenglashtirish
    }
}
