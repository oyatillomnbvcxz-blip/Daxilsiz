# Daxilsiz Suhbat - Secure Sandbox Architecture

Ushbu repozitoriy "Daxilsiz Suhbat" kiberxavfsizlik ilovasining internetsiz, tashqi muhitdan butunlay izolyatsiya qilingan xavfsiz "Sandiq" (Secure Sandbox/Container) arxitekturasini o'z ichiga oladi.

## 📦 Arxitektura Konsepti
Ilova ikki qismdan iborat:
1. **Tashqi Qobiq (Secure Container Shell):** Viruslar, josus dasturlar va begona shaxslardan himoya qiluvchi, biometrik va PIN-kod qulfiga ega bo'lgan kiber-sandiq.
2. **Ichki Yadrosi (Offline Crypto Engine):** Internetga ulanmaydigan, super sun'iy intellekt tizimlari ham buza olmaydigan noyob shifrlash algoritmi ishlaydigan xavfsiz hudud.

## 📂 Loyiha Tuzilishi (Project Structure)
- `core/`: Shifrlash va kalitlarni saqlash mexanizmlari.
- `sandbox/`: Shaxsiy ma'lumotlarni shifrlab saqlash va ekranni himoya qilish tizimi.
- `ui/`: PIN-kod va biometrik kirish qobig'i.
